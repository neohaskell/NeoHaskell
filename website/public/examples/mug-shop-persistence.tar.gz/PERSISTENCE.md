# Optional Postgres checkpoint

These files are the persistence chapter's replacements for `src/App.hs` and
`src/Shop/Config.hs`, plus a separate `src/Shop/Storage.hs` factory in the completed `mug-shop` Build checkpoint. The Cart, Stock,
and test modules remain those of the main example. This directory is an overlay,
not a standalone project or a framework checkout.

This overlay uses the same upcoming framework release and corrected CLI preset
as the Build checkpoint. Its Cart and Stock modules now rely on the five derive
helpers exported by `Core`, including `deriveEntity`. The released 0.10.0
framework pin `25bd7027a85b8f2999602f66b46b4b6b133c22e8` is not sufficient.

Before that derive-helper migration, the full Postgres checkpoint compiled its
application and test executables successfully without accessing a database.
Compilation of the current combined checkpoint was not repeated after the
derive-helper migration; the earlier result does not validate these changed
downloads. See setup for release availability.

Start with the application you created using `neo new mug-shop` and completed
through the Build lessons. Save your work, then replace the matching files and add the storage module
with the files under this directory's `src/`. From the application's root:

```sh
neo build
```

Compilation does not require a database. Running the application does. Follow the
persistence chapter to start the generated project's local Docker Compose
service, or supply another isolated Postgres database. Its defaults use the local
Compose service's `neohaskell` database and user; the password must be supplied:

```sh
DB_PASSWORD=neohaskell neo run
```

Stop the application before running HTTP tests, because the test command starts
its own server and writes to the selected database:

```sh
DB_PASSWORD=neohaskell neo test
```

Use a disposable database for those tests. If another service occupies host port
5432, choose a different host mapping in `docker-compose.yml` and supply the same
`DB_PORT` to the application and tests. No database operation should target an
unrelated local service.

The `persistEvents` field is retained to make this overlay a direct extension of
the preceding configuration lesson. It no longer controls the Postgres store and
can be removed if nothing else uses it. Switching stores does not migrate events
from the earlier in-memory process or its optional local event files.

The [persistence lesson](https://neohaskell.org/operate/persistence/) shows focused
excerpts from these complete files around the preceding application wiring. Treat
compilation, database startup, restart durability, and backup/restore as separate
checks; a successful build proves only the first.
