# Application checkpoint

These files belong in the project you created with neo new mug-shop. Extract
them into that project root, keeping the src/ and tests/ paths. They do not
replace neo.json, your launcher, or your generated project settings.

Make a commit or save your own changes before applying a checkpoint. Later
checkpoints replace earlier versions of the same feature files; merge changes
you made independently. Remove the generated Counter files and tests as shown
in the first-cart lesson. Continue using neo build, neo run, and neo test.

These examples require the upcoming framework release exporting the five derive
helpers through Core, including deriveEntity, and the corrected Neo compiler
preset described in setup. The published 0.10.0 framework pin lacks those helpers;
a corrected CLI alone is insufficient.

Lessons: https://neohaskell.org/build/first-cart/
